# modules/ssti.py
from urllib.parse import urljoin

def scan_ssti(session, url, forms, logger, tech):
    """Scan for Server-Side Template Injection"""
    findings = []
    
    if not forms:
        return findings
    
    payload = "{{7*7}}"
    expected = "49"
    
    for form in forms:
        if not isinstance(form, dict):
            continue
            
        action = form.get("action")
        method = form.get("method", "get").lower()
        inputs = form.get("inputs", [])
        
        if not inputs:
            continue
        
        target = urljoin(url, action) if action else url
        
        for input_field in inputs:
            if isinstance(input_field, dict):
                input_name = input_field.get("name")
                input_type = input_field.get("type", "text")
                if input_type in ["submit", "button", "image"]:
                    continue
            else:
                input_name = input_field
            
            if not input_name:
                continue
            
            try:
                data = {input_name: payload}
                
                if method == "post":
                    r = session.post(target, data=data, timeout=10)
                else:
                    r = session.get(target, params=data, timeout=10)
                
                if expected in r.text:
                    logger.debug(f"SSTI execution detected at {target}")
                    findings.append({
                        "type": "Server-Side Template Injection",
                        "severity": "Critical",
                        "payload": payload,
                        "parameter": input_name,
                        "response": r,
                        "confirmed": True,
                        "evidence": f"Expression {payload} evaluated to {expected}"
                    })
                    
            except Exception as e:
                logger.debug(f"SSTI scan error on {target}: {e}")
    
    return findings
