import logging
from logging.handlers import RotatingFileHandler

def setup_logger():
    logger = logging.getLogger("sentinel")
    logger.setLevel(logging.INFO)

    handler = RotatingFileHandler(
        "sentinel.log", maxBytes=500000, backupCount=5
    )

    formatter = logging.Formatter(
        "%(asctime)s [%(levelname)s] %(message)s"
    )

    handler.setFormatter(formatter)
    logger.addHandler(handler)

    return logger

