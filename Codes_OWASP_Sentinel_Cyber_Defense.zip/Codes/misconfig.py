# modules/misconfig.py
from urllib.parse import urljoin

COMMON_FILES = [
    ".git/config",
    ".env",
    "backup.zip",
    "backup.tar.gz",
    "wp-config.php",
    "config.php",
    "phpinfo.php",
    "info.php",
    "test.php",
    "robots.txt",
    "sitemap.xml",
    ".DS_Store",
    "php.ini",
    "composer.json",
    "package.json",
    "README.md",
    ".gitignore"
]

COMMON_DIRS = [
    "backup/",
    "backups/",
    "admin/",
    "phpmyadmin/",
    "uploads/",
    "images/",
    "css/",
    "js/",
    "vendor/",
    "logs/",
    "tmp/"
]

def scan_misconfig(session, url, forms, logger, tech):
    """Scan for misconfigurations and exposed files"""
    findings = []
    
    # Test common files
    file_findings = test_common_files(session, url, logger)
    findings.extend(file_findings)
    
    # Test common directories
    dir_findings = test_common_dirs(session, url, logger)
    findings.extend(dir_findings)
    
    # Check directory listing
    listing_findings = test_directory_listing(session, url, logger)
    findings.extend(listing_findings)
    
    return findings

def test_common_files(session, base_url, logger):
    """Test for common exposed files"""
    findings = []
    
    for file_path in COMMON_FILES:
        try:
            test_url = urljoin(base_url, file_path)
            r = session.get(test_url, timeout=5)
            
            if r.status_code == 200:
                # Check if it's not an error page
                if len(r.text) > 100 and "404" not in r.text and "not found" not in r.text.lower():
                    logger.debug(f"Exposed file found: {file_path}")
                    findings.append({
                        "type": "Information Disclosure",
                        "severity": "Medium",
                        "url": test_url,
                        "file": file_path,
                        "response": r,
                        "confirmed": True,
                        "evidence": f"File accessible at {test_url}"
                    })
                    
        except Exception as e:
            logger.debug(f"Error checking {file_path}: {e}")
    
    return findings

def test_common_dirs(session, base_url, logger):
    """Test for common directories"""
    findings = []
    
    for dir_path in COMMON_DIRS:
        try:
            test_url = urljoin(base_url, dir_path)
            r = session.get(test_url, timeout=5)
            
            if r.status_code == 200:
                # Check if it's a directory listing
                if "Index of /" in r.text or "<title>Index of" in r.text:
                    logger.debug(f"Directory found: {dir_path}")
                    findings.append({
                        "type": "Directory Exposure",
                        "severity": "Low",
                        "url": test_url,
                        "directory": dir_path,
                        "response": r,
                        "confirmed": True,
                        "evidence": f"Directory accessible at {test_url}"
                    })
                    
        except Exception as e:
            logger.debug(f"Error checking {dir_path}: {e}")
    
    return findings

def test_directory_listing(session, base_url, logger):
    """Test for directory listing enabled"""
    findings = []
    
    test_paths = ["images/", "css/", "js/", "uploads/", "assets/"]
    
    for path in test_paths:
        try:
            test_url = urljoin(base_url, path)
            r = session.get(test_url, timeout=5)
            
            if r.status_code == 200:
                if "Index of /" in r.text or "<title>Index of" in r.text:
                    logger.debug(f"Directory listing enabled: {path}")
                    findings.append({
                        "type": "Directory Listing",
                        "severity": "Low",
                        "url": test_url,
                        "response": r,
                        "confirmed": True,
                        "evidence": "Directory listing is enabled"
                    })
                    
        except Exception as e:
            logger.debug(f"Error checking directory listing: {e}")
    
    return findings
