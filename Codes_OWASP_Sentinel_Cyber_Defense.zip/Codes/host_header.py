# modules/host_header.py
def scan_host_header(session, url, forms, logger, tech):
    """Scan for Host Header Injection vulnerabilities"""
    findings = []
    
    # Test with malicious Host header
    test_payloads = [
        "evil.com",
        "localhost",
        "127.0.0.1",
        "evil.com:80"
    ]
    
    for payload in test_payloads:
        try:
            headers = {"Host": payload}
            r = session.get(url, headers=headers, timeout=10)
            
            # Check for Host header reflection
            if payload in r.text:
                logger.debug(f"Host header injection detected with payload: {payload}")
                findings.append({
                    "type": "Host Header Injection",
                    "severity": "Low",
                    "payload": payload,
                    "response": r,
                    "confirmed": True,
                    "evidence": f"Host header value reflected in response"
                })
                break
                
        except Exception as e:
            logger.debug(f"Error testing host header: {e}")
    
    return findings
