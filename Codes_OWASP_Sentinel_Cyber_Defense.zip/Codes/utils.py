# core/utils.py
from urllib.parse import urlparse

def normalize_url(url):
    """Normalize URL by adding scheme if missing"""
    if not url:
        return ""
    if not url.startswith(("http://", "https://")):
        url = "https://" + url
    return url.rstrip("/")

def is_same_domain(url1, url2):
    """Check if two URLs have the same domain"""
    try:
        domain1 = urlparse(url1).netloc
        domain2 = urlparse(url2).netloc
        return domain1 == domain2
    except:
        return False

def extract_domain(url):
    """Extract domain from URL"""
    try:
        return urlparse(url).netloc
    except:
        return ""
