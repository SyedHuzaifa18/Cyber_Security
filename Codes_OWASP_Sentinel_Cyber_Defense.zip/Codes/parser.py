# core/parser.py
from bs4 import BeautifulSoup
from urllib.parse import urlparse, parse_qs

def extract_forms(html):
    """Extract all forms from HTML"""
    if not html:
        return []
    
    try:
        soup = BeautifulSoup(html, "html.parser")
        forms = []

        for form in soup.find_all("form"):
            inputs = []
            for inp in form.find_all("input"):
                name = inp.get("name")
                if name and name.lower() not in ["submit", "button"]:
                    input_type = inp.get("type", "text")
                    inputs.append({
                        "name": name,
                        "type": input_type,
                        "value": inp.get("value", "")
                    })

            forms.append({
                "action": form.get("action"),
                "method": form.get("method", "get").lower(),
                "inputs": inputs,
                "id": form.get("id"),
                "name": form.get("name")
            })

        return forms
    except Exception:
        return []

def extract_url_params(url):
    """Extract parameters from URL"""
    try:
        parsed = urlparse(url)
        if parsed.query:
            return parse_qs(parsed.query)
        return {}
    except Exception:
        return {}

def extract_inputs(form):
    """Extract input fields from a form"""
    inputs = {}
    try:
        for i in form.find_all("input"):
            name = i.get("name")
            if name:
                inputs[name] = i.get("value", "")
    except Exception:
        pass
    return inputs

def get_form_details(form):
    """Get detailed form information"""
    details = {}
    try:
        action = form.attrs.get("action", "").lower()
        method = form.attrs.get("method", "get").lower()
        inputs = []
        
        for input_tag in form.find_all("input"):
            input_type = input_tag.attrs.get("type", "text")
            input_name = input_tag.attrs.get("name")
            input_value = input_tag.attrs.get("value", "")
            if input_name:
                inputs.append({
                    "type": input_type,
                    "name": input_name,
                    "value": input_value
                })
        
        details["action"] = action
        details["method"] = method
        details["inputs"] = inputs
    except Exception:
        pass
    return details
