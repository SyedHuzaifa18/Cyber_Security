# reporting/json_report.py
import json
from datetime import datetime
import os

def generate_json_report(findings, stats, target):
    """Generate JSON report"""
    
    # Create reports directory if it doesn't exist
    if not os.path.exists("reports"):
        os.makedirs("reports")
    
    # Clean findings for JSON serialization
    clean_findings = []
    for f in findings:
        clean_f = {}
        for key, value in f.items():
            if key == "response":
                # Convert response object to dict
                clean_f[key] = {
                    "status_code": value.status_code if hasattr(value, "status_code") else None,
                    "url": value.url if hasattr(value, "url") else None,
                    "headers": dict(value.headers) if hasattr(value, "headers") else {},
                    "text_length": len(value.text) if hasattr(value, "text") else 0
                }
            elif key == "tech_stack" and isinstance(value, dict):
                clean_f[key] = {k: v for k, v in value.items() if v is not None}
            else:
                try:
                    json.dumps({key: value})
                    clean_f[key] = value
                except:
                    clean_f[key] = str(value)
        clean_findings.append(clean_f)
    
    report = {
        "generated_at": datetime.now().isoformat(),
        "target": target,
        "stats": {k: str(v) if isinstance(v, datetime) else v for k, v in stats.items()},
        "total_findings": len(findings),
        "findings": clean_findings
    }
    
    with open("reports/scan_report.json", "w", encoding="utf-8") as f:
        json.dump(report, f, indent=4, default=str)
