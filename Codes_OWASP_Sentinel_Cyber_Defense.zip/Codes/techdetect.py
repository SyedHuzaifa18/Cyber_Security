# core/techdetect.py
import re

def detect_tech_stack(response, url):
    """Enhanced technology stack detection"""
    tech = {
        "backend": "unknown",
        "template": None,
        "framework": None,
        "server": "unknown",
        "database": None,
        "os": None,
        "waf": None
    }
    
    try:
        headers = response.headers
        server = headers.get("Server", "").lower()
        
        # Server detection
        if server:
            tech["server"] = server
            if "apache" in server:
                tech["os"] = "Linux/Unix"
            elif "nginx" in server:
                tech["os"] = "Linux/Unix"
            elif "iis" in server:
                tech["os"] = "Windows"
            elif "cloudflare" in server:
                tech["waf"] = "Cloudflare"
        
        # Backend detection from X-Powered-By
        powered_by = headers.get("X-Powered-By", "").lower()
        if "php" in powered_by:
            tech["backend"] = "php"
        elif "asp.net" in powered_by:
            tech["backend"] = "asp.net"
        elif "express" in powered_by:
            tech["backend"] = "node.js"
        
        # Backend detection from URL/file extensions
        if ".php" in url:
            tech["backend"] = "php"
        elif ".asp" in url or ".aspx" in url:
            tech["backend"] = "asp.net"
        elif ".jsp" in url:
            tech["backend"] = "java"
        elif ".py" in url:
            tech["backend"] = "python"
        
        # Check body if available
        if response.text:
            body = response.text.lower()
            
            # Framework detection
            if "wp-content" in body or "wordpress" in body:
                tech["framework"] = "wordpress"
                tech["backend"] = "php"
            elif "django" in body or "csrfmiddlewaretoken" in body:
                tech["framework"] = "django"
                tech["backend"] = "python"
                tech["template"] = "django"
            elif "laravel" in body or "laravel_session" in body:
                tech["framework"] = "laravel"
                tech["backend"] = "php"
            
            # Template engine detection
            if re.search(r"{{.*}}", body) or re.search(r"{%.*%}", body):
                tech["template"] = "jinja2"
            elif re.search(r"${.*}", body):
                tech["template"] = "freemarker"
    
    except Exception:
        pass
    
    return tech
