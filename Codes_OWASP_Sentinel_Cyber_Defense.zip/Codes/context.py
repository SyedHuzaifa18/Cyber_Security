from bs4 import BeautifulSoup

def extract_forms(html):
    soup = BeautifulSoup(html, "html.parser")
    return soup.find_all("form")

def extract_inputs(form):
    inputs = {}
    for i in form.find_all("input"):
        name = i.get("name")
        if name:
            inputs[name] = i.get("value", "test")
    return inputs

