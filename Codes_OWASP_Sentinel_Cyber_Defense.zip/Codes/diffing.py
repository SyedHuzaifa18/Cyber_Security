# core/diffing.py
import difflib

def response_diff_score(baseline, test):
    """
    Returns similarity score between two responses (0–100)
    Lower score = more behavioral difference
    """
    seq = difflib.SequenceMatcher(
        None,
        baseline.text,
        test.text
    )
    return int(seq.ratio() * 100)

