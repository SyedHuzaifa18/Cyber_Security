# modules/xss.py
from urllib.parse import urlparse, parse_qs, urlencode, urlunparse, urljoin
import html
import re

XSS_PAYLOADS = [
    "<script>alert(1)</script>",
    "<img src=x onerror=alert(1)>",
    "<svg onload=alert(1)>",
    "javascript:alert(1)",
    "\"><script>alert(1)</script>",
    "'><script>alert(1)</script>"
]

def scan_xss(session, url, forms, logger, tech):
    """Main XSS scanning function"""
    findings = []
    
    # Test URL parameters
    if "?" in url:
        param_findings = test_url_parameters_xss(session, url, logger)
        findings.extend(param_findings)
    
    # Test form inputs
    if forms:
        for form in forms:
            form_findings = test_form_inputs_xss(session, url, form, logger)
            findings.extend(form_findings)
    
    return findings

def test_url_parameters_xss(session, url, logger):
    """Test URL parameters for XSS"""
    findings = []
    
    try:
        parsed = urlparse(url)
        params = parse_qs(parsed.query)
        
        if not params:
            return findings
        
        logger.debug(f"Testing {len(params)} URL parameters for XSS on {url}")
        
        for param_name in params.keys():
            for payload in XSS_PAYLOADS:
                try:
                    test_url = inject_param_xss(url, param_name, payload)
                    r = session.get(test_url, timeout=10)
                    
                    if payload in r.text:
                        logger.debug(f"XSS reflected in parameter {param_name}")
                        findings.append({
                            "type": "Cross-Site Scripting (Reflected)",
                            "severity": "Medium",
                            "payload": payload,
                            "parameter": param_name,
                            "location": "url",
                            "response": r,
                            "confirmed": True,
                            "evidence": f"Payload reflected in response"
                        })
                        break
                        
                except Exception as e:
                    logger.debug(f"Error testing XSS: {e}")
    
    except Exception as e:
        logger.debug(f"Error in URL XSS test: {e}")
    
    return findings

def test_form_inputs_xss(session, url, form, logger):
    """Test form inputs for XSS"""
    findings = []
    
    try:
        if not form or not isinstance(form, dict):
            return findings
        
        action = form.get("action")
        method = form.get("method", "get").lower()
        inputs = form.get("inputs", [])
        
        if not inputs:
            return findings
        
        target = urljoin(url, action) if action else url
        logger.debug(f"Testing {len(inputs)} form inputs for XSS on {target}")
        
        for input_field in inputs:
            if isinstance(input_field, dict):
                input_name = input_field.get("name")
                input_type = input_field.get("type", "text")
                if input_type in ["submit", "button", "image"]:
                    continue
            else:
                input_name = input_field
            
            if not input_name:
                continue
            
            for payload in XSS_PAYLOADS:
                try:
                    data = {input_name: payload}
                    
                    if method == "post":
                        r = session.post(target, data=data, timeout=10)
                    else:
                        r = session.get(target, params=data, timeout=10)
                    
                    if payload in r.text:
                        logger.debug(f"XSS reflected in form input {input_name}")
                        findings.append({
                            "type": "Cross-Site Scripting (Reflected)",
                            "severity": "Medium",
                            "payload": payload,
                            "parameter": input_name,
                            "location": "form",
                            "response": r,
                            "confirmed": True,
                            "evidence": f"Payload reflected in response"
                        })
                        break
                        
                except Exception as e:
                    logger.debug(f"Error testing form XSS: {e}")
    
    except Exception as e:
        logger.debug(f"Error in form XSS test: {e}")
    
    return findings

def inject_param_xss(url, param_name, payload):
    """Inject payload into URL parameter"""
    try:
        parsed = urlparse(url)
        params = parse_qs(parsed.query)
        params[param_name] = [payload]
        new_query = urlencode(params, doseq=True)
        return urlunparse(parsed._replace(query=new_query))
    except:
        return url
