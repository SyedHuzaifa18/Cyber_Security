# modules/open_redirect.py
from urllib.parse import urlparse, parse_qs, urlencode, urlunparse, urljoin

def scan_open_redirect(session, url, forms, logger, tech):
    """Scan for open redirect vulnerabilities"""
    findings = []
    
    # Common redirect parameters
    redirect_params = [
        "next", "redirect", "redirect_uri", "redirect_url", "return", 
        "return_to", "return_url", "url", "link", "goto", "destination",
        "out", "view", "dir", "file", "path", "continue", "referer",
        "referrer", "callback", "return_path", "target", "redir"
    ]
    
    # Test URL parameters
    if "?" in url:
        param_findings = test_url_redirect(session, url, redirect_params, logger)
        findings.extend(param_findings)
    
    # Test form inputs
    if forms:
        for form in forms:
            form_findings = test_form_redirect(session, url, form, redirect_params, logger)
            findings.extend(form_findings)
    
    return findings

def test_url_redirect(session, url, redirect_params, logger):
    """Test URL parameters for open redirect"""
    findings = []
    
    try:
        parsed = urlparse(url)
        params = parse_qs(parsed.query)
        
        if not params:
            return findings
        
        test_payload = "https://evil.com"
        
        for param_name in params.keys():
            if param_name.lower() in redirect_params:
                try:
                    test_url = inject_param(url, param_name, test_payload)
                    r = session.get(test_url, allow_redirects=False, timeout=10)
                    
                    # Check for redirect
                    if r.status_code in [301, 302, 303, 307, 308]:
                        location = r.headers.get("Location", "")
                        if test_payload in location:
                            logger.debug(f"Open redirect detected in parameter {param_name}")
                            findings.append({
                                "type": "Open Redirect",
                                "severity": "Medium",
                                "payload": test_payload,
                                "parameter": param_name,
                                "location": "url",
                                "response": r,
                                "confirmed": True,
                                "evidence": f"Redirects to: {location}"
                            })
                            
                except Exception as e:
                    logger.debug(f"Error testing open redirect: {e}")
    
    except Exception as e:
        logger.debug(f"Error in URL redirect test: {e}")
    
    return findings

def test_form_redirect(session, url, form, redirect_params, logger):
    """Test form inputs for open redirect"""
    findings = []
    
    try:
        if not form or not isinstance(form, dict):
            return findings
        
        action = form.get("action")
        method = form.get("method", "get").lower()
        inputs = form.get("inputs", [])
        
        if not inputs:
            return findings
        
        target = urljoin(url, action) if action else url
        test_payload = "https://evil.com"
        
        for input_field in inputs:
            if isinstance(input_field, dict):
                input_name = input_field.get("name")
                input_type = input_field.get("type", "text")
                if input_type in ["submit", "button", "image"]:
                    continue
            else:
                input_name = input_field
            
            if not input_name:
                continue
            
            if input_name.lower() in redirect_params:
                try:
                    data = {input_name: test_payload}
                    
                    if method == "post":
                        r = session.post(target, data=data, allow_redirects=False, timeout=10)
                    else:
                        r = session.get(target, params=data, allow_redirects=False, timeout=10)
                    
                    if r.status_code in [301, 302, 303, 307, 308]:
                        location = r.headers.get("Location", "")
                        if test_payload in location:
                            findings.append({
                                "type": "Open Redirect",
                                "severity": "Medium",
                                "payload": test_payload,
                                "parameter": input_name,
                                "location": "form",
                                "response": r,
                                "confirmed": True,
                                "evidence": f"Redirects to: {location}"
                            })
                            
                except Exception as e:
                    logger.debug(f"Error testing form redirect: {e}")
    
    except Exception as e:
        logger.debug(f"Error in form redirect test: {e}")
    
    return findings

def inject_param(url, param_name, payload):
    """Inject payload into URL parameter"""
    try:
        parsed = urlparse(url)
        params = parse_qs(parsed.query)
        params[param_name] = [payload]
        new_query = urlencode(params, doseq=True)
        return urlunparse(parsed._replace(query=new_query))
    except:
        return url
