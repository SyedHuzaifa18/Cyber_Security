# reporting/html_report.py
from datetime import datetime
import os
import html as html_escape

def generate_html_report(findings, stats, target):
    """Generate HTML report"""
    
    # Create reports directory if it doesn't exist
    if not os.path.exists("reports"):
        os.makedirs("reports")
    
    html = """<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>OWASP Sentinel Security Report</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; background: #f5f5f5; }
        .container { max-width: 1200px; margin: 0 auto; background: white; padding: 20px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
        h1 { color: #e74c3c; border-bottom: 3px solid #e74c3c; padding-bottom: 10px; }
        .summary { background: #ecf0f1; padding: 15px; border-radius: 5px; margin: 20px 0; }
        .stat-box { display: inline-block; margin-right: 30px; }
        .stat-value { font-size: 24px; font-weight: bold; color: #2c3e50; }
        .stat-label { color: #7f8c8d; }
        .finding { border: 1px solid #ddd; padding: 15px; margin: 10px 0; border-radius: 5px; }
        .critical { border-left: 5px solid #c0392b; background: #fdf3f2; }
        .high { border-left: 5px solid #e67e22; background: #fef5e7; }
        .medium { border-left: 5px solid #f1c40f; background: #fef9e7; }
        .low { border-left: 5px solid #3498db; background: #ebf5fb; }
        .info { border-left: 5px solid #2ecc71; background: #eafaf1; }
        .severity-badge { display: inline-block; padding: 3px 8px; border-radius: 3px; color: white; font-size: 12px; }
        .severity-critical { background: #c0392b; }
        .severity-high { background: #e67e22; }
        .severity-medium { background: #f1c40f; color: black; }
        .severity-low { background: #3498db; }
        .severity-info { background: #2ecc71; }
        .details { margin-top: 10px; padding-top: 10px; border-top: 1px solid #eee; }
        pre { background: #f8f9fa; padding: 10px; border-radius: 5px; overflow-x: auto; }
        .footer { margin-top: 30px; text-align: center; color: #7f8c8d; font-size: 12px; }
    </style>
</head>
<body>
    <div class="container">
        <h1>🔍 OWASP Sentinel Security Report</h1>
"""
    
    # Summary section
    html += f"""
        <div class="summary">
            <h2>Scan Summary</h2>
            <div class="stat-box">
                <div class="stat-value">{stats.get('urls_scanned', 0)}</div>
                <div class="stat-label">URLs Scanned</div>
            </div>
            <div class="stat-box">
                <div class="stat-value">{stats.get('forms_tested', 0)}</div>
                <div class="stat-label">Forms Tested</div>
            </div>
            <div class="stat-box">
                <div class="stat-value">{stats.get('parameters_tested', 0)}</div>
                <div class="stat-label">Parameters Tested</div>
            </div>
            <div class="stat-box">
                <div class="stat-value">{len(findings)}</div>
                <div class="stat-label">Total Findings</div>
            </div>
            <p><strong>Target:</strong> {target}</p>
            <p><strong>Scan Start:</strong> {stats.get('start_time', 'N/A')}</p>
            <p><strong>Scan End:</strong> {stats.get('end_time', 'N/A')}</p>
        </div>
"""
    
    if findings:
        # Group findings by severity
        severity_order = ["Critical", "High", "Medium", "Low", "Info"]
        grouped = {sev: [] for sev in severity_order}
        
        for f in findings:
            sev = f.get("severity", "Info")
            if sev in grouped:
                grouped[sev].append(f)
            else:
                grouped["Info"].append(f)
        
        # Findings by severity
        for severity in severity_order:
            if grouped[severity]:
                html += f"<h2>{severity} Severity Findings ({len(grouped[severity])})</h2>"
                
                for f in grouped[severity]:
                    css_class = severity.lower()
                    html += f"""
                    <div class="finding {css_class}">
                        <div>
                            <span class="severity-badge severity-{css_class}">{severity}</span>
                            <strong>{html_escape.escape(f.get('type', 'Unknown Vulnerability'))}</strong>
                        </div>
                        <div class="details">
                            <p><strong>URL:</strong> <a href="{f.get('url', '#')}" target="_blank">{f.get('url', 'N/A')}</a></p>
                            <p><strong>Module:</strong> {f.get('applied_module', 'N/A')}</p>
                            <p><strong>Confidence:</strong> {f.get('confidence', 0)}%</p>
                            <p><strong>CVSS Score:</strong> {f.get('cvss', 'N/A')}</p>
                    """
                    
                    if f.get('parameter'):
                        html += f"<p><strong>Parameter:</strong> {html_escape.escape(str(f['parameter']))}</p>"
                    
                    if f.get('payload'):
                        html += f"<p><strong>Payload:</strong> <code>{html_escape.escape(str(f['payload']))}</code></p>"
                    
                    if f.get('evidence'):
                        html += f"<p><strong>Evidence:</strong> {html_escape.escape(str(f['evidence']))}</p>"
                    
                    html += "</div></div>"
    else:
        html += """
        <div style="text-align: center; padding: 40px; background: #ecf0f1; border-radius: 5px;">
            <h2>✅ No Vulnerabilities Found</h2>
            <p>The scan completed without detecting any security issues.</p>
        </div>
        """
    
    html += f"""
        <div class="footer">
            Generated by OWASP Sentinel on {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
        </div>
    </div>
</body>
</html>
    """
    
    with open("reports/scan_report.html", "w", encoding="utf-8") as f:
        f.write(html)
