# core/crawler.py
from urllib.parse import urljoin, urlparse
from bs4 import BeautifulSoup
import time

def crawl(session, base_url, limit=20, log=None):
    """Crawl the target website to discover URLs"""
    visited = set()
    to_visit = [base_url]
    
    try:
        base_domain = urlparse(base_url).netloc
    except:
        base_domain = ""
    
    if log:
        log(f"Starting crawl on {base_url}")
    
    while to_visit and len(visited) < limit:
        url = to_visit.pop(0)
        
        if url in visited:
            continue
        
        # Add small delay to be polite
        time.sleep(0.3)
        
        try:
            if log:
                log(f"Crawling: {url}")
                
            r = session.get(url, timeout=10)
            
            # Check if response is HTML
            content_type = r.headers.get('Content-Type', '')
            if 'text/html' not in content_type.lower():
                if log:
                    log(f"Skipping non-HTML: {content_type}")
                visited.add(url)
                continue
                
        except Exception as e:
            if log:
                log(f"Failed to crawl {url}: {e}")
            continue
        
        visited.add(url)
        
        # Parse HTML and extract links
        try:
            if not r.text:
                continue
                
            soup = BeautifulSoup(r.text, "html.parser")
            
            for a in soup.find_all("a", href=True):
                href = a['href'].strip()
                
                # Skip empty links, javascript, mailto, etc.
                if not href or href.startswith(('#', 'javascript:', 'mailto:', 'tel:')):
                    continue
                
                # Convert relative to absolute URL
                link = urljoin(url, href)
                
                # Parse the link
                try:
                    parsed_link = urlparse(link)
                except:
                    continue
                
                # Only follow links to the same domain
                if parsed_link.netloc == base_domain or not parsed_link.netloc:
                    # Remove fragments
                    link = parsed_link._replace(fragment='').geturl()
                    
                    # Add to queue if not visited
                    if link not in visited and link not in to_visit:
                        to_visit.append(link)
                        
        except Exception as e:
            if log:
                log(f"Error parsing {url}: {e}")
            continue
    
    if log:
        log(f"Crawl complete. Found {len(visited)} URLs")
    
    return list(visited)
