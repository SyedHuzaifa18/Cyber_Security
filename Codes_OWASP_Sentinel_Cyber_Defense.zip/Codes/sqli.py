# modules/sqli.py
from urllib.parse import urlparse, parse_qs, urlencode, urlunparse, urljoin
import time

SQL_ERRORS = [
    "you have an error in your sql syntax",
    "warning: mysql",
    "unclosed quotation mark",
    "quoted string not properly terminated",
    "mysql_fetch",
    "mysql_num_rows",
    "mysql_result",
    "odbc",
    "microsoft ole db",
    "sqlite",
    "sqlite3",
    "postgresql",
    "pg_query",
    "syntax error"
]

def scan_sqli(session, url, forms, logger, tech):
    """Main SQLi scanning function"""
    findings = []
    
    # Test URL parameters
    if "?" in url:
        param_findings = test_url_parameters(session, url, logger)
        findings.extend(param_findings)
    
    # Test form inputs
    if forms:
        for form in forms:
            if form and isinstance(form, dict):
                form_findings = test_form_inputs(session, url, form, logger)
                findings.extend(form_findings)
    
    return findings

def test_url_parameters(session, url, logger):
    """Test URL parameters for SQL injection"""
    findings = []
    
    try:
        parsed = urlparse(url)
        params = parse_qs(parsed.query)
        
        if not params:
            return findings
        
        logger.debug(f"Testing {len(params)} URL parameters on {url}")
        
        for param_name in params.keys():
            # Test error-based
            error_findings = test_error_sqli(session, url, param_name, logger)
            findings.extend(error_findings)
    
    except Exception as e:
        logger.debug(f"Error in URL parameter test: {e}")
    
    return findings

def test_form_inputs(session, url, form, logger):
    """Test form inputs for SQL injection"""
    findings = []
    
    try:
        if not form or not isinstance(form, dict):
            return findings
        
        action = form.get("action")
        method = form.get("method", "get").lower()
        inputs = form.get("inputs", [])
        
        if not inputs:
            return findings
        
        target = urljoin(url, action) if action else url
        logger.debug(f"Testing {len(inputs)} form inputs on {target}")
        
        for input_field in inputs:
            if isinstance(input_field, dict):
                input_name = input_field.get("name")
                input_type = input_field.get("type", "text")
                if input_type in ["submit", "button", "image"]:
                    continue
            else:
                input_name = input_field
                
            if not input_name:
                continue
            
            # Test error-based
            error_findings = test_form_error_sqli(session, target, method, input_name, logger)
            findings.extend(error_findings)
    
    except Exception as e:
        logger.debug(f"Error in form input test: {e}")
    
    return findings

def test_error_sqli(session, url, param_name, logger):
    """Test for error-based SQL injection"""
    findings = []
    
    error_payloads = ["'", "\"", "1'", "1\""]
    
    for payload in error_payloads:
        try:
            test_url = inject_param(url, param_name, payload)
            r = session.get(test_url, timeout=10)
            response_text = r.text.lower()
            
            for error in SQL_ERRORS:
                if error in response_text:
                    logger.debug(f"Error-based SQLi detected with payload: {payload}")
                    findings.append({
                        "type": "SQL Injection (Error-Based)",
                        "severity": "High",
                        "payload": payload,
                        "parameter": param_name,
                        "location": "url",
                        "response": r,
                        "confirmed": True,
                        "evidence": f"Error pattern: {error}"
                    })
                    return findings
                    
        except Exception as e:
            logger.debug(f"Error in error-based test: {e}")
    
    return findings

def test_form_error_sqli(session, target, method, input_name, logger):
    """Test form inputs for error-based SQL injection"""
    findings = []
    
    error_payloads = ["'", "\"", "1'", "1\""]
    
    for payload in error_payloads:
        try:
            data = {input_name: payload}
            
            if method == "post":
                r = session.post(target, data=data, timeout=10)
            else:
                r = session.get(target, params=data, timeout=10)
                
            response_text = r.text.lower()
            
            for error in SQL_ERRORS:
                if error in response_text:
                    findings.append({
                        "type": "SQL Injection (Error-Based)",
                        "severity": "High",
                        "payload": payload,
                        "parameter": input_name,
                        "location": "form",
                        "response": r,
                        "confirmed": True,
                        "evidence": f"Error pattern: {error}"
                    })
                    return findings
                    
        except Exception as e:
            logger.debug(f"Error in form error test: {e}")
    
    return findings

def inject_param(url, param_name, payload):
    """Inject payload into URL parameter"""
    try:
        parsed = urlparse(url)
        params = parse_qs(parsed.query)
        params[param_name] = [payload]
        new_query = urlencode(params, doseq=True)
        return urlunparse(parsed._replace(query=new_query))
    except:
        return url
