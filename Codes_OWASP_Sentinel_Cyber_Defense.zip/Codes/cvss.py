# core/cvss.py

def calculate_cvss(severity, confidence):
    """
    Lightweight CVSS-style scoring (academic-safe)
    """
    base = {
        "Low": 3.1,
        "Medium": 6.5,
        "High": 8.8,
        "Critical": 9.8
    }.get(severity, 0)

    modifier = confidence / 100
    return round(base * modifier, 1)

